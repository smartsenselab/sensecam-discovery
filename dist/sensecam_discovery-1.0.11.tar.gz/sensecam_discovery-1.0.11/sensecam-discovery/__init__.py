name = 'SenseCamDiscovery'
from sensecam_discovery import SenseCamDiscovery