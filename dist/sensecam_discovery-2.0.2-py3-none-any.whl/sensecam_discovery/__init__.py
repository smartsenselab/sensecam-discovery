__name__ = 'sensecam_discovery'
__version__ = '2.0.2'

from sensecam_discovery.SenseCamDiscovery import Camera, discover
